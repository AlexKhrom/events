<template>
  <v-app style="padding: 20px;">
    <template v-if="page==='add'">
      <v-btn class="mb-2" @click="page='list'" color="primary">Show all</v-btn>
      <v-btn @click="add(title)" class="mb-2" v-for="title in $store.state.titles" :key="title">{{ title }}</v-btn>
    </template>
    <template v-else>
      <v-btn class="mb-2" @click="page='add'" color="primary">+ Add</v-btn>
      <div style="display: flex;justify-content: space-between;" v-for="(event,index) in $store.state.events"
           :key="event.title+event.dt">
        <div :style="event.deleted?'opacity: 0.5':''"
             style="font-size: 18px;text-transform: capitalize;display: flex;align-items: center;">{{ event.title }}
        </div>
        <div>
          <span v-if="!event.deleted" style="color: #555;font-size: 12px">{{ $moment(event.dt).fromNow() }}</span>
          <span v-else style="color: #555;font-size: 12px;padding-right: 10px">{{ event.waitSeconds }}с</span>
          <v-btn v-if="event.deleted" @click="camebackEvent(index)" text small>вернуть ↩︎</v-btn>
          <v-btn v-else @click="deleteEvent(index)" icon>🗑</v-btn>
        </div>
      </div>
    </template>
  </v-app>
</template>

<script>
// import {Bar} from 'vue-chartjs/legacy'


export default {

  name: 'App',
  // components: {Bar},
  data() {
    return {
      page: 'add',
      timer: 10,
      timerId: 0,
    }
  },
  methods: {
    add(title) {
      this.$store.state.events.push({
        title,
        dt: Date.now()
      })
      localStorage.setItem('events', JSON.stringify(this.$store.state.events))
      this.page = 'list';
    },
    deleteEvent(index) {
      let event = this.$store.state.events[index]

      let waitSeconds = 3
      event.waitSeconds = waitSeconds
      let intervalId = setInterval(() => {
        if (!event.deleted) {
          clearInterval(intervalId)
          return
        }
        if (--waitSeconds < 0) {
          clearInterval(intervalId);
          this.$store.state.events.splice(index, 1)
        } else {
          event.waitSeconds = waitSeconds
        }
        this.$forceUpdate()
      }, 1000);

      // this.$store.state.events.splice(index, 1)

      event.deleted = Date.now();
      this.$forceUpdate();
      localStorage.setItem('events', JSON.stringify(this.$store.state.events))
    },
    camebackEvent(index) {
      this.$store.state.events[index].deleted = 0
      this.$forceUpdate();
    }
  },
}
</script>
