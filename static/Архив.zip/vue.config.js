module.exports = {
  transpileDependencies: [
    'vuetify'
  ],
}
